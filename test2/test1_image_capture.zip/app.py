from flask import Flask, render_template, request
import cv2
import os

app = Flask(__name__)

def capture_image():
    # Initialize the video capture
    video_capture = cv2.VideoCapture(0)
    
    # Read frame from the webcam
    success, frame = video_capture.read()
    
    if success:
        # Save the captured frame as an image file
        image_path = 'static/captured_image.jpg'
        cv2.imwrite(image_path, frame)
        
        # Release the video capture
        video_capture.release()
        
        return image_path
    
    # If the capture was unsuccessful, return None
    return None

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # If the form is submitted, capture an image
        image_path = capture_image()
    else:
        # If the page is loaded initially, set image_path to None
        image_path = None
    
    return render_template('index.html', image_path=image_path)

if __name__ == '__main__':
    # Remove the previously captured image if exists
    os.remove('static/captured_image.jpg')
    
    # Run the Flask application
    app.run(debug=True)
